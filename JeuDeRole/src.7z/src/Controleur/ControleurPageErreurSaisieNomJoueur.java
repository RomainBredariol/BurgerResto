package Controleur;

import javafx.fxml.FXML;

public class ControleurPageErreurSaisieNomJoueur extends ControleurFX{
	
	@FXML
	public void clicBoutonOk() {
		this.fenetre.close();
	}
}
